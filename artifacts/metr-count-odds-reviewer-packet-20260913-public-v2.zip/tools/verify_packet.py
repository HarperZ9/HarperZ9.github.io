#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
from typing import Any

ROOT = pathlib.Path(__file__).resolve().parents[1]
RECEIPTS = ROOT / "receipts"
EXPECTED = {
    "correct": {"score_value": 1, "score_answer": "6", "typed_outcome": "complete_structural_import"},
    "wrong": {"score_value": 0, "score_answer": "1", "typed_outcome": "complete_structural_import"},
    "no_submit_tool_call": {"score_value": 0, "score_answer": "NO_SUBMISSION_CONTROL", "typed_outcome": "complete_structural_import"},
}
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
GIT_SHA_RE = re.compile(r"^[0-9a-f]{40}$")
CONTROL_CHARS_RE = re.compile(r"[\x00-\x1f\x7f]")
WINDOWS_DRIVE_RE = re.compile(r"^[A-Za-z]:")


def sha256(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: pathlib.Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def display_path(path: pathlib.Path) -> str:
    resolved = path.resolve()
    try:
        return resolved.relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return str(resolved)


def packet_path_from_safe_posix(value: object, *, line: int | None = None) -> tuple[pathlib.Path | None, list[str]]:
    problems: list[str] = []
    if type(value) is not str:
        return None, ["path_not_string"]
    raw = value
    label = f" line {line}" if line is not None else ""
    if raw == "":
        problems.append(f"empty_path{label}")
    if raw.strip() != raw:
        problems.append(f"path_has_surrounding_whitespace{label}")
    if CONTROL_CHARS_RE.search(raw):
        problems.append(f"path_has_control_character{label}")
    if "\\" in raw:
        problems.append(f"path_has_backslash{label}")
    if raw.startswith("/") or raw.startswith("//"):
        problems.append(f"path_is_absolute{label}")
    if WINDOWS_DRIVE_RE.match(raw):
        problems.append(f"path_has_windows_drive{label}")
    if ":" in raw:
        problems.append(f"path_has_colon_or_ads{label}")
    if "//" in raw:
        problems.append(f"path_has_empty_segment{label}")
    posix = pathlib.PurePosixPath(raw)
    parts = posix.parts
    if not parts or parts[0] != "receipts":
        problems.append(f"path_not_under_receipts{label}")
    if any(part in ("", ".", "..") for part in parts):
        problems.append(f"path_has_dot_or_empty_segment{label}")
    if len(parts) <= 1:
        problems.append(f"path_names_receipts_without_file{label}")
    if problems:
        return None, problems
    candidate = (ROOT / pathlib.Path(*parts)).resolve()
    try:
        candidate.relative_to(RECEIPTS.resolve())
    except ValueError:
        problems.append(f"resolved_path_escapes_receipts{label}")
    return candidate, problems


def verify_manifest() -> list[dict[str, Any]]:
    manifest = RECEIPTS / "all-receipts-sha256.txt"
    rows: list[dict[str, Any]] = []
    for line_no, line in enumerate(manifest.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        parts = line.split(None, 1)
        problems: list[str] = []
        if len(parts) != 2:
            rows.append({"line": line_no, "path": None, "problems": ["manifest_line_malformed"], "match": False})
            continue
        expected, name = parts[0], parts[1].strip()
        if not SHA256_RE.fullmatch(expected):
            problems.append("expected_sha256_malformed")
        path, path_problems = packet_path_from_safe_posix(name, line=line_no)
        problems.extend(path_problems)
        exists = path.exists() if path is not None else False
        actual = sha256(path) if path is not None and exists else None
        if not exists:
            problems.append("missing_file")
        elif actual != expected:
            problems.append("sha256_mismatch")
        rows.append({
            "line": line_no,
            "path": name,
            "exists": exists,
            "expected_sha256": expected,
            "actual_sha256": actual,
            "problems": problems,
            "match": not problems,
        })
    return rows


def verify_control_summary() -> dict[str, Any]:
    summary_path = RECEIPTS / "summary" / "control-summary.json"
    summary = load_json(summary_path)
    observed: dict[str, Any] = {}
    problems: list[str] = []
    if type(summary) is not list:
        return {"observed": observed, "problems": ["control_summary_not_list"], "ok": False}
    seen: set[str] = set()
    for row in summary:
        if type(row) is not dict:
            problems.append("control_summary_row_not_object")
            continue
        control = row.get("control")
        if control in seen:
            problems.append(f"duplicate control {control!r}")
            continue
        seen.add(str(control))
        if control not in EXPECTED:
            problems.append(f"unexpected control {control!r}")
            continue
        exp = EXPECTED[control]
        observed[control] = {
            "classification": row.get("classification", {}).get("status") if isinstance(row.get("classification"), dict) else None,
            "task_name": row.get("task_name"),
            "task_version": row.get("task_version"),
            "sample_id": row.get("sample_id"),
            "log_eval_model": row.get("log_eval_model"),
            "score_name": row.get("score_name"),
            "score_value": row.get("score_value"),
            "score_answer": row.get("score_answer"),
            "solver_answer": row.get("solver_answer"),
        }
        if observed[control]["classification"] != "pass":
            problems.append(f"{control}: classification not pass")
        for key in ("score_value", "score_answer"):
            if row.get(key) != exp[key]:
                problems.append(f"{control}: {key} expected {exp[key]!r}, got {row.get(key)!r}")
        if row.get("task_name") != "count_odds" or row.get("task_version") != "0.0.1" or row.get("sample_id") != "hard":
            problems.append(f"{control}: wrong task/version/sample")
        if row.get("log_eval_model") != "none/none":
            problems.append(f"{control}: model was not none/none")
        if row.get("score_name") != "score_metr_task":
            problems.append(f"{control}: scorer was not score_metr_task")
    if seen != set(EXPECTED):
        problems.append(f"control_set_mismatch expected {sorted(EXPECTED)} got {sorted(seen)}")
    return {"observed": observed, "problems": problems, "ok": not problems}


def expected_flywheel_rev() -> str:
    return (RECEIPTS / "source" / "flywheel-head.txt").read_text(encoding="utf-8").strip()


def verify_source_pin() -> dict[str, Any]:
    path = RECEIPTS / "source" / "flywheel-head.txt"
    problems: list[str] = []
    try:
        rev = path.read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        return {
            "path": display_path(path),
            "expected_rev": None,
            "problems": ["missing_source_head"],
            "ok": False,
        }
    if not GIT_SHA_RE.fullmatch(rev):
        problems.append("unpinned_source_head")
    return {
        "path": display_path(path),
        "expected_rev": rev,
        "problems": problems,
        "ok": not problems,
    }


def read_importer_source_hashes() -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    source = RECEIPTS / "source" / "flywheel-importer-source-sha256.txt"
    for line_no, line in enumerate(source.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        parts = line.split()
        if len(parts) != 3:
            raise ValueError(f"malformed importer source hash line {line_no}")
        digest, rev, path = parts
        if not SHA256_RE.fullmatch(digest):
            raise ValueError(f"malformed sha256 in importer source hash line {line_no}")
        if rev != expected_flywheel_rev():
            raise ValueError(f"importer source hash rev mismatch on line {line_no}: {rev}")
        if "\\" in path or path.startswith("/") or ".." in pathlib.PurePosixPath(path).parts or ":" in path:
            raise ValueError(f"unsafe importer source path on line {line_no}: {path}")
        rows.append({"sha256": digest, "rev": rev, "path": path})
    return rows


def validate_flywheel_source(flywheel_source: pathlib.Path) -> dict[str, Any]:
    source = flywheel_source.resolve()
    expected_rev = expected_flywheel_rev()
    result: dict[str, Any] = {"path": str(source), "expected_rev": expected_rev, "problems": []}
    if not (source / "harness" / "cli_entry.py").exists():
        result["problems"].append("missing_harness_cli_entry")
        result["ok"] = False
        return result
    try:
        head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True, stderr=subprocess.STDOUT).strip()
    except subprocess.CalledProcessError as exc:
        result["problems"].append(f"git_rev_parse_failed: {exc.output.strip()}")
        result["ok"] = False
        return result
    result["head"] = head
    if head != expected_rev:
        result["problems"].append("flywheel_head_mismatch")
    relevant = read_importer_source_hashes()
    result["relevant_source_files"] = relevant
    paths = [row["path"] for row in relevant]
    try:
        status = subprocess.check_output(["git", "status", "--porcelain", "--", *paths], cwd=source, text=True, stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError as exc:
        status = exc.output
        result["problems"].append("git_status_failed")
    result["relevant_git_status"] = status.splitlines()
    if status.strip():
        result["problems"].append("relevant_source_not_clean")
    hash_rows = []
    for row in relevant:
        file_path = source / pathlib.Path(*pathlib.PurePosixPath(row["path"]).parts)
        actual = sha256(file_path) if file_path.exists() else None
        ok = actual == row["sha256"]
        if not ok:
            result["problems"].append(f"relevant_source_hash_mismatch:{row['path']}")
        hash_rows.append({"path": row["path"], "expected_sha256": row["sha256"], "actual_sha256": actual, "ok": ok})
    result["relevant_source_hashes"] = hash_rows
    result["ok"] = not result["problems"]
    return result


def verify_recorded_outcomes() -> dict[str, Any]:
    rows = []
    problems: list[str] = []
    seen: set[str] = set()
    expected_rev = expected_flywheel_rev()
    files = sorted((RECEIPTS / "flywheel-import").glob("*.outcome.json"))
    for path in files:
        row = load_json(path)
        if type(row) is not dict:
            problems.append(f"{path.name}: outcome_not_object")
            continue
        control = row.get("control")
        if control in seen:
            problems.append(f"duplicate recorded outcome {control!r}")
        seen.add(str(control))
        if control not in EXPECTED:
            problems.append(f"unexpected recorded outcome {control!r}")
            continue
        exp = EXPECTED[control]
        safe_outcome_rel = f"receipts/flywheel-import/{path.name}"
        _, outcome_path_problems = packet_path_from_safe_posix(safe_outcome_rel)
        if outcome_path_problems:
            problems.append(f"{control}: unsafe outcome path")
        if row.get("exit_code") != 0:
            problems.append(f"{control}: recorded exit_code not 0")
        if row.get("typed_outcome") != exp["typed_outcome"]:
            problems.append(f"{control}: typed_outcome mismatch")
        if row.get("flywheel_rev") != expected_rev:
            problems.append(f"{control}: flywheel_rev mismatch")
        if not SHA256_RE.fullmatch(str(row.get("source_sha256", ""))):
            problems.append(f"{control}: source_sha256 malformed")
        json_path, json_problems = packet_path_from_safe_posix(row.get("json_file"))
        stdout_path, stdout_problems = packet_path_from_safe_posix(row.get("stdout_path"))
        stderr_path, stderr_problems = packet_path_from_safe_posix(row.get("stderr_path"))
        for label, path_problems in (("json_file", json_problems), ("stdout_path", stdout_problems), ("stderr_path", stderr_problems)):
            if path_problems:
                problems.append(f"{control}: {label} unsafe: {path_problems}")
        json_hash = sha256(json_path) if json_path is not None and json_path.exists() else None
        if json_hash != row.get("source_sha256"):
            problems.append(f"{control}: json source hash mismatch")
        for label, ref_path in (("json_file", json_path), ("stdout_path", stdout_path), ("stderr_path", stderr_path)):
            if ref_path is None or not ref_path.exists():
                problems.append(f"{control}: {label} missing")
        rows.append(row | {"outcome_path": display_path(path), "json_actual_sha256": json_hash})
    if seen != set(EXPECTED):
        problems.append(f"recorded_outcome_control_set_mismatch expected {sorted(EXPECTED)} got {sorted(seen)}")
    return {"rows": rows, "problems": problems, "ok": not problems}


def run_imports(flywheel_source: pathlib.Path, out_dir: pathlib.Path, recorded_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONPYCACHEPREFIX"] = str(out_dir / ".pycache")
    for row in recorded_rows:
        json_path, problems = packet_path_from_safe_posix(row["json_file"])
        if problems or json_path is None:
            rows.append({"control": row.get("control"), "ok": False, "problems": problems})
            continue
        cmd = [sys.executable, "-m", "harness.cli_entry", "import-inspect", str(json_path), "--expected-sha256", row["source_sha256"]]
        proc = subprocess.run(cmd, cwd=flywheel_source, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        stem = pathlib.Path(row["json_file"]).name
        stdout_path = out_dir / f"{stem}.rerun.stdout.txt"
        stderr_path = out_dir / f"{stem}.rerun.stderr.txt"
        stdout_path.write_text(proc.stdout, encoding="utf-8")
        stderr_path.write_text(proc.stderr, encoding="utf-8")
        parsed = None
        parse_error = None
        try:
            parsed = json.loads(proc.stdout)
        except Exception as exc:  # noqa: BLE001 - diagnostic only
            parse_error = str(exc)
        rows.append({
            "control": row["control"],
            "cmd": "python -m harness.cli_entry import-inspect <json> --expected-sha256 <sha256>",
            "exit_code": proc.returncode,
            "expected_exit_code": row["exit_code"],
            "source_sha256": row["source_sha256"],
            "stdout_path": display_path(stdout_path),
            "stderr_path": display_path(stderr_path),
            "semantic_verification": parsed.get("semantic_verification") if isinstance(parsed, dict) else None,
            "reported_status": parsed.get("reported_status") if isinstance(parsed, dict) else None,
            "assessment": parsed.get("assessment") if isinstance(parsed, dict) else None,
            "parse_error": parse_error,
            "ok": proc.returncode == row["exit_code"] and isinstance(parsed, dict) and parsed.get("semantic_verification") == "UNVERIFIABLE",
        })
    return rows


def run_mutation_check(flywheel_source: pathlib.Path, out_dir: pathlib.Path, recorded_rows: list[dict[str, Any]]) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    correct = next(row for row in recorded_rows if row["control"] == "correct")
    src, problems = packet_path_from_safe_posix(correct["json_file"])
    if problems or src is None:
        return {"ok": False, "problems": problems, "mutation": "not_run"}
    data = load_json(src)
    data["samples"][0]["scores"]["score_metr_task"]["value"] = 0
    data["samples"][0]["scores"]["score_metr_task"]["explanation"] = "SEEDED_PACKET_MUTATION: score value changed after recorded hash"
    mutated = out_dir / "correct-score-mutated.eval.json"
    mutated.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONPYCACHEPREFIX"] = str(out_dir / ".pycache")
    cmd = [sys.executable, "-m", "harness.cli_entry", "import-inspect", str(mutated), "--expected-sha256", correct["source_sha256"]]
    proc = subprocess.run(cmd, cwd=flywheel_source, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
    stdout_path = out_dir / "correct-score-mutated.stdout.txt"
    stderr_path = out_dir / "correct-score-mutated.stderr.txt"
    stdout_path.write_text(proc.stdout, encoding="utf-8")
    stderr_path.write_text(proc.stderr, encoding="utf-8")
    parsed = None
    parse_error = None
    try:
        parsed = json.loads(proc.stdout)
    except Exception as exc:  # noqa: BLE001 - diagnostic only
        parse_error = str(exc)
    schema_ok = isinstance(parsed, dict) and parsed.get("schema") == "flywheel.inspect-import-error/v1"
    error_ok = isinstance(parsed, dict) and parsed.get("error") == "SOURCE_DIGEST_MISMATCH"
    return {
        "mutation": "changed correct score_metr_task.value from 1 to 0 and changed explanation",
        "mutated_path": display_path(mutated),
        "mutated_sha256": sha256(mutated),
        "original_expected_sha256": correct["source_sha256"],
        "cmd": "python -m harness.cli_entry import-inspect mutated --expected-sha256 <original-sha256>",
        "exit_code": proc.returncode,
        "expected_exit_code": 2,
        "stdout_path": display_path(stdout_path),
        "stderr_path": display_path(stderr_path),
        "error_schema": parsed.get("schema") if isinstance(parsed, dict) else None,
        "error": parsed.get("error") if isinstance(parsed, dict) else None,
        "parse_error": parse_error,
        "ok": proc.returncode == 2 and schema_ok and error_ok,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify the public-safe METR count_odds reviewer packet")
    parser.add_argument("--flywheel-source", type=pathlib.Path, help="Exact Flywheel checkout at receipts/source/flywheel-head.txt")
    parser.add_argument("--out", type=pathlib.Path, default=ROOT / "verification" / "latest")
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    source_pin = verify_source_pin()
    manifest_rows = verify_manifest()
    control = verify_control_summary()
    recorded = verify_recorded_outcomes()
    result: dict[str, Any] = {
        "schema": "flywheel.metr-count-odds-reviewer-packet-verification/v1",
        "packet_root": str(ROOT),
        "source_pin": source_pin,
        "manifest": {
            "checked": len(manifest_rows),
            "mismatches": [row for row in manifest_rows if not row["match"]],
        },
        "control_summary": control,
        "recorded_import_outcomes": recorded,
    }
    if args.flywheel_source:
        if source_pin["ok"]:
            source_check = validate_flywheel_source(args.flywheel_source)
            result["flywheel_source"] = source_check
        else:
            source_check = {
                "ok": False,
                "problems": ["SKIPPED: source pin is not an exact full commit SHA"],
                "expected_rev": source_pin["expected_rev"],
            }
            result["flywheel_source"] = source_check
        if source_check["ok"]:
            import_dir = args.out / "import-rerun"
            result["import_rerun"] = run_imports(args.flywheel_source.resolve(), import_dir, recorded["rows"])
            result["mutation_check"] = run_mutation_check(args.flywheel_source.resolve(), args.out / "mutation", recorded["rows"])
        else:
            result["import_rerun"] = "SKIPPED: flywheel source check failed"
            result["mutation_check"] = "SKIPPED: flywheel source check failed"
    else:
        result["flywheel_source"] = "SKIPPED: pass --flywheel-source to check exact source pin and rerun import-inspect"
        result["import_rerun"] = "SKIPPED: pass --flywheel-source to rerun import-inspect"
        result["mutation_check"] = "SKIPPED: pass --flywheel-source to run changed-byte control"

    out_json = args.out / "verification-result.json"
    out_json.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    ok = not result["manifest"]["mismatches"] and source_pin["ok"] and control["ok"] and recorded["ok"]
    if isinstance(result.get("flywheel_source"), dict):
        ok = ok and result["flywheel_source"]["ok"]
    if isinstance(result.get("import_rerun"), list):
        ok = ok and all(row["ok"] for row in result["import_rerun"])
    if isinstance(result.get("mutation_check"), dict):
        ok = ok and result["mutation_check"]["ok"]
    print(json.dumps({"ok": ok, "result": display_path(out_json)}, indent=2))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
