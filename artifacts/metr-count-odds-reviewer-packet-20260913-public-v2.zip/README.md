# METR count_odds reviewer packet — public bundle

This bundle is a public-safe reviewer packet for the METR `count_odds` bridge acceptance in Flywheel PR234. It uses the already-merged PR234 bridge artifacts and existing runner scripts. It does not include copied METR bridge source, built task images, private correspondence, secrets, or any claim of independent adoption.

## Contents

- `receipts/`: the GitHub Actions artifact `metr-count-odds-bridge-receipts` from run `34750411689`.
- `provenance/`: selected public GitHub API metadata for PR234, the successful workflow run, and the artifact.
- `runner/`: scripts and workflow wrapper for rerunning the full upstream interop check in an owned GitHub repository.
- `tools/verify_packet.py`: local verifier for the receipt packet.
- `PUBLIC-FILE-MANIFEST.sha256`: public bundle file manifest.
- `SUMMARY-RECEIPT.json`: public-safe packet summary.

`PUBLIC-BUNDLE-ALLOWLIST.txt` lists every file included in the archive, including
itself and the public manifest. `PUBLIC-FILE-MANIFEST.sha256` hashes every listed
file except itself, avoiding a circular hash. The archive is distributed with an
external SHA-256 file. These hashes detect differences from the supplied reference;
they do not authenticate the publisher or establish semantic correctness.

## Pinned evidence

| Item | Pinned value | Evidence path |
| --- | --- | --- |
| PR | <https://github.com/HarperZ9/flywheel/pull/234>, merged 2026-09-13T10:01:07Z | `provenance/pr234-merged.json` |
| PR head | `5be8bdc8d4eeb408bb7d3ac946dec415e1bc27f7` | `provenance/pr234-merged.json`; `provenance/github-run-final.json` |
| Merge commit | `d28200a78c16cf2a970104d8a5f057a526b8cfa0` | `provenance/pr234-merged.json` |
| GitHub run | `34750411689`, conclusion `success` | `provenance/github-run-final.json` |
| Artifact | `metr-count-odds-bridge-receipts`, digest `sha256:5fbc9be298fb90b501bcfe8b0c0af58177f236bc0a74a3ed12358551c3deae69` | `provenance/github-artifact-api.json` |
| METR bridge source | `METR/inspect-metr-task-bridge@20a430cc59283c8b463e526e77f8d040509457ec` | `receipts/source/bridge-head.txt`; `receipts/source/source-urls.tsv` |
| Task Standard source | `METR/task-standard@03236e9a1a0d3c9f9d63f6c9e60a9278a59d22ff` | `receipts/source/task-standard-dockerfile-pin.txt` |
| Flywheel importer source used in run | `HarperZ9/flywheel@b3ec822b4c1a942697f1370383c83beac339155e` | `receipts/source/flywheel-head.txt` |
| Runtime versions | Docker `7.1.0`, `inspect-ai 0.3.189`, `metr-task-standard 0.1.2`, `mtb 0.5.24`, `oras 0.2.38` | `receipts/source/runtime-versions.json` |
| Bridge license boundary | No license file detected at pinned bridge commit | `receipts/source/bridge-license-status.txt` |

Exact source URL and SHA-256 lists are retained in `receipts/source/source-urls.tsv`, `receipts/source/source-sha256.txt`, `receipts/source/flywheel-importer-source-urls.tsv`, and `receipts/source/flywheel-importer-source-sha256.txt`.

## Deterministic outcomes retained

The run used the upstream `count_odds` hard sample. The task asks for the number of odd digits in `[6,4,1,4,0,6,8,1,3,5,7,9]`; the exact answer is `6`. The runner used Inspect's no-provider path, with `log_eval_model` recorded as `none/none`.

| Control | Solver behavior | Observed score | Expected check |
| --- | --- | --- | --- |
| `correct` | Submit `6` | `score_metr_task = 1` | Pass |
| `wrong` | Submit `1` | `score_metr_task = 0` | Pass |
| `no_submit_tool_call` | Emit plain text, no `submit` tool call | `score_metr_task = 0`; score answer is `NO_SUBMISSION_CONTROL` | Pass as a no-submit-tool-call control only |

The `no_submit_tool_call` control is not claimed as a true no-answer proof. The upstream scorer falls back to output completion, so this packet retains the fallback answer and labels the limit.

## Verify this extracted bundle locally

Run these commands from the extracted bundle root. They use an exact Flywheel checkout for reproducibility.

```powershell
New-Item -ItemType Directory -Force -Path .\_verify | Out-Null
git clone -c core.autocrlf=false -c core.eol=lf --no-checkout --filter=blob:none --sparse https://github.com/HarperZ9/flywheel.git .\_verify\flywheel-b3ec822b
git -C .\_verify\flywheel-b3ec822b sparse-checkout set harness docs/INSPECT-EVIDENCE.md tests/test_inspect_evidence_cli.py
git -C .\_verify\flywheel-b3ec822b checkout b3ec822b4c1a942697f1370383c83beac339155e
python .\tools\verify_packet.py --flywheel-source .\_verify\flywheel-b3ec822b --out .\_verify\packet-verification
```

Expected result:

```json
{
  "ok": true,
  "result": "_verify/packet-verification/verification-result.json"
}
```

The verifier checks:

1. Every file named by `receipts/all-receipts-sha256.txt` exists and matches its SHA-256.
2. `receipts/summary/control-summary.json` contains the three expected controls and deterministic scores.
3. `python -m harness.cli_entry import-inspect <json> --expected-sha256 <sha256>` exits `0` for each exported Inspect JSON and reports `semantic_verification: UNVERIFIABLE`.
4. A seeded mutation of the correct JSON changes `score_metr_task.value` from `1` to `0`, then reuses the original expected source SHA-256. The expected outcome is exit `2`, because changed evidence bytes must not pass under the old hash.

## Full upstream interop rerun

Use an owned GitHub repository with Actions enabled. The full rerun requires Docker/buildx, network access to GitHub, PyPI, Docker Hub/GHCR, Ubuntu package mirrors, and Playwright browser downloads. It starts a local registry on the runner, builds the actual upstream `count_odds` task image using `mtb-build`, pushes the image and task-info OCI artifact only to that local registry, runs Inspect on `mtb/bridge`, dumps Inspect logs to JSON, imports each JSON through Flywheel, and uploads receipts.

Copy the runner files into the repository:

```bash
mkdir -p .github/workflows metr-runner-plan
cp /path/to/extracted-bundle/runner/github-actions-metr-count-odds.yml .github/workflows/metr-count-odds.yml
cp /path/to/extracted-bundle/runner/run_count_odds_controls.py metr-runner-plan/run_count_odds_controls.py
cp /path/to/extracted-bundle/runner/control_outcome.py metr-runner-plan/control_outcome.py
cp /path/to/extracted-bundle/runner/test_control_outcome.py metr-runner-plan/test_control_outcome.py
```

Then run the workflow and download the artifact:

```bash
gh workflow run metr-count-odds.yml
gh run list --workflow 'METR task bridge interoperability' --limit 5
gh run download <run-id> -n metr-count-odds-bridge-receipts --dir ./metr-count-odds-bridge-receipts
```

Do not publish the built image or bridge source from this packet. The pinned bridge source has no license file recorded in `receipts/source/bridge-license-status.txt`.

## What this establishes

- Upstream interop: a GitHub-hosted Ubuntu runner built the real METR `count_odds` task image and task-info artifact from the pinned bridge source, then executed it through Inspect and imported the resulting JSON with Flywheel.
- Evidence custody: the packet carries raw `.eval` logs, JSON dumps, source hashes, Docker manifest receipts, Flywheel import stdout/stderr/outcomes, and an all-receipts SHA-256 manifest.
- Control behavior: correct, wrong, and no-submit-tool-call controls were observed with deterministic scores.

## What this does not establish

- It is not a general METR Task Standard conformance claim.
- It is not model-performance evidence. The run used deterministic no-provider behavior and logged `none/none`.
- It does not independently prove the upstream scorer is semantically correct. Flywheel import keeps scorer values as reported evidence with `semantic_verification: UNVERIFIABLE`.
- It is not an installed Flywheel release claim, a package/tag claim, or evidence of independent adoption.
- It does not resolve the missing-license boundary for redistributing the METR bridge code or built images.
