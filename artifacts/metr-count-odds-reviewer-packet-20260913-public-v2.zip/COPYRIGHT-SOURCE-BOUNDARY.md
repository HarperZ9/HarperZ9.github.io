# Source and redistribution boundary

This public bundle intentionally does not include copied METR bridge source files or built task images. The bridge source is referenced by public URLs, commit IDs, and SHA-256 hashes in `receipts/source/source-urls.tsv` and `receipts/source/source-sha256.txt`.

Generated receipts are included: Inspect `.eval` logs, Inspect JSON exports, Flywheel import stdout/stderr/outcome JSON, Docker manifest receipts, source URL/hash inventories, and runtime/version receipts.

The pinned METR bridge commit recorded `NO LICENSE FILE`; do not redistribute bridge code or built images from this packet unless separate licensing clearance exists. The included runner scripts are packet-side review helpers, not copied bridge source.
